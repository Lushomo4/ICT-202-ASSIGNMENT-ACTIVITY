-import java.util.Stack;

public class InfixConverter {

    private static int precedence(char op) {
        switch (op) {
            case '+': case '-': return 1;
            case '*': case '/': return 2;
            case '^':           return 3;
            default:            return -1;
        }
    }

    private static boolean isOperand(char ch) {
        return Character.isLetterOrDigit(ch);
    }

    public static String infixToPostfix(String infix) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < infix.length(); i++) {
            char ch = infix.charAt(i);

            if (ch == ' ') continue;

            if (isOperand(ch)) {
                result.append(ch);
            } else if (ch == '(') {
                stack.push(ch);
            } else if (ch == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop());
                }
                if (!stack.isEmpty()) stack.pop();
            } else {
                while (!stack.isEmpty()
                        && stack.peek() != '('
                        && precedence(stack.peek()) >= precedence(ch)) {
                    result.append(stack.pop());
                }
                stack.push(ch);
            }
        }

        while (!stack.isEmpty()) {
            result.append(stack.pop());
        }

        return result.toString();
    }

    public static String infixToPrefix(String infix) {
        StringBuilder reversed = new StringBuilder();
        for (int i = infix.length() - 1; i >= 0; i--) {
            char ch = infix.charAt(i);
            if      (ch == '(') reversed.append(')');
            else if (ch == ')') reversed.append('(');
            else                reversed.append(ch);
        }
        String postfix = infixToPostfix(reversed.toString());
        return new StringBuilder(postfix).reverse().toString();
    }

    private static boolean isBalanced(String expr) {
        int count = 0;
        for (char ch : expr.toCharArray()) {
            if (ch == '(') count++;
            else if (ch == ')') count--;
            if (count < 0) return false;
        }
        return count == 0;
    }

    public static void main(String[] args) {
        String[] expressions = {
            "A+B*C",
            "A+B*C-D",
            "(A+B)*(C-D)",
            "A*(B+C)/D",
            "A^B^C",
            "((A+B)*C-(D-E))^(F+G)"
        };

        System.out.println("=".repeat(62));
        System.out.printf("%-30s %-15s %-15s%n", "Infix", "Postfix", "Prefix");
        System.out.println("=".repeat(62));

        for (String expr : expressions) {
            if (!isBalanced(expr)) {
                System.out.printf("%-30s  [unbalanced parentheses]%n", expr);
                continue;
            }
            String postfix = infixToPostfix(expr);
            String prefix  = infixToPrefix(expr);
            System.out.printf("%-30s %-15s %-15s%n", expr, postfix, prefix);
        }

        System.out.println("=".repeat(62));

        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.print("Enter an infix expression (or 'quit' to exit): ");

        while (scanner.hasNextLine()) {
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("quit")) break;
            if (input.isEmpty()) {
                System.out.print("Enter an infix expression (or 'quit' to exit): ");
                continue;
            }
            if (!isBalanced(input)) {
                System.out.println("Error: Unbalanced parentheses.");
            } else {
                System.out.println("Postfix : " + infixToPostfix(input));
                System.out.println("Prefix  : " + infixToPrefix(input));
            }
            System.out.print("\nEnter an infix expression (or 'quit' to exit): ");
        }
        scanner.close();
    }
}
